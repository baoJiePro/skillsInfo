#!/bin/bash
# init-gateway.sh - OpenClaw Gateway 原生多 Agent 部署脚本 (v1.0)
# 架构：异步多 Agent 协作，Liaison 单一入口，Gateway 中央路由

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置区
OPENCLAW_ROOT="${HOME}/.openclaw"
AGENTS_DIR="${OPENCLAW_ROOT}/agents"
CONFIG_FILE="${OPENCLAW_ROOT}/openclaw.json"
AGENTS_INFO_DIR="$(pwd)/agentsInfo"

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     OpenClaw Gateway 多 Agent 部署脚本 (异步协作架构)          ║"
echo "║                                                              ║"
echo "║  特点:                                                       ║"
echo "║  • Liaison 单一入口，秒级响应                                 ║"
echo "║  • Gateway 中央路由，异步处理                                 ║"
echo "║  • 12 个专业 Agent，记忆隔离                                  ║"
echo "║  • 任务状态追踪，主动推送                                     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# 检查依赖
echo -e "${YELLOW}🔍 检查依赖...${NC}"

# 检查 Node.js 版本
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ 错误: 未找到 Node.js，请先安装 Node.js 22+${NC}"
    exit 1
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 22 ]; then
    echo -e "${RED}❌ 错误: Node.js 版本过低 ($NODE_VERSION)，需要 22+${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Node.js $(node --version)${NC}"

# 检查 OpenClaw CLI
if ! command -v openclaw &> /dev/null; then
    echo -e "${YELLOW}⚠️ 未找到 OpenClaw CLI，将自动安装...${NC}"
    curl -fsSL https://openclaw.ai/install.sh | bash
    # 重新加载 PATH
    export PATH="$HOME/.local/bin:$PATH"
fi
echo -e "${GREEN}✅ OpenClaw $(openclaw --version)${NC}"

# 检查 agentsInfo 目录
if [ ! -d "$AGENTS_INFO_DIR" ]; then
    echo -e "${RED}❌ 错误: 未找到 agentsInfo 目录！请在项目根目录运行此脚本${NC}"
    exit 1
fi

# 创建目录结构
echo -e "${YELLOW}📂 创建目录结构...${NC}"
mkdir -p "${AGENTS_DIR}"
mkdir -p "${OPENCLAW_ROOT}/logs"
mkdir -p "${OPENCLAW_ROOT}/data"

# Agent 列表
AGENTS=(
    "liaison-spark"
    "commander-grove"
    "ceo-bezos"
    "cto-vogels"
    "fullstack-dhh"
    "product-norman"
    "qa-bach"
    "ui-duarte"
    "interaction-cooper"
    "marketing-godin"
    "sales-ross"
    "operations-pg"
)

# 部署 Agent
echo -e "${YELLOW}🧠 部署 Agent...${NC}"

for agent_id in "${AGENTS[@]}"; do
    echo -e "${BLUE}  部署 ${agent_id}...${NC}"
    
    agent_dir="${AGENTS_DIR}/${agent_id}"
    mkdir -p "${agent_dir}/workspace"
    
    # 使用 v2 版本的 liaison
    if [ "$agent_id" = "liaison-spark" ]; then
        source_file="${AGENTS_INFO_DIR}/${agent_id}-v2.md"
        if [ ! -f "$source_file" ]; then
            source_file="${AGENTS_INFO_DIR}/${agent_id}.md"
        fi
    else
        source_file="${AGENTS_INFO_DIR}/${agent_id}.md"
    fi
    
    if [ -f "$source_file" ]; then
        # 复制为 system.md (OpenClaw 标准)
        cp "$source_file" "${agent_dir}/system.md"
        echo -e "${GREEN}    ✅ system.md${NC}"
    else
        echo -e "${RED}    ⚠️ 未找到 ${source_file}${NC}"
    fi
done

# 生成 openclaw.json 配置文件
echo -e "${YELLOW}⚙️ 生成配置文件...${NC}"

cat > "${CONFIG_FILE}" <<'EOF'
{
  "agent": {
    "model": "anthropic/claude-sonnet-4",
    "defaults": {
      "workspace": "~/.openclaw/agents/liaison-spark/workspace",
      "sandbox": {
        "mode": "non-main",
        "allowlist": ["bash", "process", "read", "write", "edit", "sessions_list", "sessions_history", "sessions_send", "sessions_spawn"]
      }
    }
  },
  "channels": {
    "telegram": {
      "botToken": "${TELEGRAM_BOT_TOKEN}",
      "groups": {
        "*": {
          "requireMention": false
        }
      }
    },
    "discord": {
      "token": "${DISCORD_TOKEN}",
      "dmPolicy": "pairing"
    }
  },
  "gateway": {
    "bind": "127.0.0.1:18789",
    "auth": {
      "mode": "password"
    }
  }
}
EOF

echo -e "${YELLOW}⚠️ 注意: OpenClaw 官方配置不支持多 Agent 路由${NC}"
echo -e "${YELLOW}   多 Agent 功能需要在应用层或 Agent system prompt 中实现${NC}"
echo -e "${YELLOW}   详见: routing-design.md${NC}"

echo -e "${GREEN}✅ 配置文件已生成: ${CONFIG_FILE}${NC}"

# 创建环境变量模板
echo -e "${YELLOW}📝 创建环境变量模板...${NC}"

cat > "$(pwd)/.env.example" <<'EOF'
# OpenClaw Gateway 环境变量配置
# 复制此文件为 .env 并填写实际值

# 飞书配置 (用于消息推送)
FEISHU_WEBHOOK_URL=https://open.feishu.cn/open-apis/bot/v2/hook/xxxxxx
FEISHU_APP_ID=cli_xxxxxx
FEISHU_APP_SECRET=xxxxxx

# OpenClaw 配置
OPENCLAW_API_KEY=sk-xxxxxxxx
OPENCLAW_MODEL_PROVIDER=anthropic

# 可选：外部存储配置
# REDIS_URL=redis://localhost:6379
# DATABASE_URL=postgresql://user:pass@localhost/openclaw
EOF

echo -e "${GREEN}✅ 环境变量模板: $(pwd)/.env.example${NC}"

# 创建启动脚本
echo -e "${YELLOW}🚀 创建启动脚本...${NC}"

cat > "$(pwd)/start-gateway.sh" <<'EOF'
#!/bin/bash
# start-gateway.sh - 启动 OpenClaw Gateway

echo "🚀 启动 OpenClaw Gateway..."

# 加载环境变量
if [ -f .env ]; then
    export $(cat .env | grep -v '^#' | xargs)
fi

# 启动 Gateway
openclaw gateway start --config ~/.openclaw/openclaw.json
EOF

chmod +x "$(pwd)/start-gateway.sh"
echo -e "${GREEN}✅ 启动脚本: $(pwd)/start-gateway.sh${NC}"

# 创建状态查询脚本
cat > "$(pwd)/query-status.sh" <<'EOF'
#!/bin/bash
# query-status.sh - 查询任务状态

if [ -z "$1" ]; then
    echo "用法: ./query-status.sh <task-id>"
    echo "示例: ./query-status.sh TASK-20240310-ECOM-ARCH-001"
    exit 1
fi

curl -s "http://localhost:18789/v1/tasks/$1" | jq .
EOF

chmod +x "$(pwd)/query-status.sh"
echo -e "${GREEN}✅ 状态查询脚本: $(pwd)/query-status.sh${NC}"

# 部署完成
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                   ✅ 部署完成！                               ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}📋 下一步操作:${NC}"
echo ""
echo "1. 配置环境变量:"
echo -e "   ${YELLOW}cp .env.example .env${NC}"
echo -e "   ${YELLOW}# 编辑 .env 文件，填写飞书配置${NC}"
echo ""
echo "2. 启动 Gateway:"
echo -e "   ${YELLOW}./start-gateway.sh${NC}"
echo ""
echo "3. 验证部署:"
echo -e "   ${YELLOW}openclaw agents list${NC}"
echo -e "   ${YELLOW}curl http://localhost:18789/health${NC}"
echo ""
echo "4. 测试 Liaison:"
echo -e "   ${YELLOW}openclaw run liaison-spark --prompt \"你好\"${NC}"
echo ""
echo -e "${BLUE}📁 部署目录:${NC}"
echo -e "   配置: ${YELLOW}~/.openclaw/openclaw.json${NC}"
echo -e "   Agents: ${YELLOW}~/.openclaw/agents/${NC}"
echo -e "   数据: ${YELLOW}~/.openclaw/data/${NC}"
echo -e "   日志: ${YELLOW}~/.openclaw/logs/${NC}"
echo ""
echo -e "${BLUE}📖 文档:${NC}"
echo -e "   部署指南: ${YELLOW}openclaw-mult-agen-v2.md${NC}"
echo -e "   联络官定义: ${YELLOW}agentsInfo/liaison-spark-v2.md${NC}"
echo ""
