# OpenClaw 多 Agent 架构改造指南 - 第1步

## 改造目标

**核心需求**：用户只与联络官沟通，联络官不做耗时任务，主要及时响应。

## 改造内容

### 1. 联络官 Agent 改造

#### 旧版 (`liaison-spark.md`)

**问题**：
- 依赖 FS-Bus 文件队列 (`docs/bus/inbox/`)
- 需要手动检查通知文件
- 与 Watcher 耦合

**架构**：
```
用户消息 → Liaison → 写入 inbox 文件 → Watcher 轮询 → Agent
```

#### 新版 (`liaison-spark-v2.md`)

**改进**：
- ✅ 明确秒级响应承诺 (< 3秒)
- ✅ 明确禁止耗时操作清单
- ✅ 使用 Gateway API 分发任务
- ✅ 通过 WebSocket 接收完成通知

**架构**：
```
用户消息 → Liaison → Gateway API → 任务队列 → Agent (异步)
                     ↓
              WebSocket 推送 ← 完成通知
```

**关键变化**：

| 项目 | 旧版 | 新版 |
|-----|------|------|
| 响应方式 | 写入文件 | Gateway API |
| 通知机制 | 读取文件 | WebSocket 推送 |
| 响应时间 | 依赖文件 I/O | < 3秒保证 |
| 耦合度 | 与 Watcher 耦合 | Gateway 解耦 |

### 2. 部署文档改造

#### 旧版 (`openclaw-mult-agen.md`)

**问题**：
- 基于 FS-Bus + Watcher 架构
- 使用 Python 脚本轮询文件
- 配置结构非标准

#### 新版 (`openclaw-mult-agen-v2.md`)

**改进**：
- ✅ Gateway 原生架构说明
- ✅ 异步多 Agent 协作设计
- ✅ 任务状态机设计
- ✅ 主动推送机制

### 3. 初始化脚本改造

#### 旧版 (`init-real-world.sh`)

**问题**：
- 创建 FS-Bus 目录结构
- 生成 Python Watcher 脚本
- 使用非标准配置格式

#### 新版 (`init-gateway.sh`)

**改进**：
- ✅ 标准 OpenClaw 目录结构
- ✅ 生成标准 `openclaw.json`
- ✅ 包含路由规则配置
- ✅ 创建启动脚本和状态查询脚本

## 文件对照表

| 用途 | 旧文件 | 新文件 | 说明 |
|-----|--------|--------|------|
| 联络官定义 | `agentsInfo/liaison-spark.md` | `agentsInfo/liaison-spark-v2.md` | 新增 Gateway 原生支持 |
| 部署文档 | `openclaw-mult-agen.md` | `openclaw-mult-agen-v2.md` | 全新 Gateway 架构 |
| 初始化脚本 | `init-real-world.sh` | `init-gateway.sh` | 标准 OpenClaw 部署 |
| 配置文件 | 自定义格式 | `~/.openclaw/openclaw.json` | 标准格式 |

## 使用方式

### 全新部署

```bash
# 1. 进入项目目录
cd /Users/baojie/Documents/myProject/skillsInfo/openclawmultagent

# 2. 运行新的初始化脚本
chmod +x init-gateway.sh
./init-gateway.sh

# 3. 配置环境变量
cp .env.example .env
# 编辑 .env 填写飞书配置

# 4. 启动 Gateway
./start-gateway.sh
```

### 验证部署

```bash
# 查看 Agent 列表
openclaw agents list

# 测试 Liaison 响应
openclaw run liaison-spark --prompt "你好"

# 测试任务创建
openclaw run liaison-spark --prompt "帮我设计一个电商网站架构"

# 查询任务状态
./query-status.sh TASK-20240310-ECOM-ARCH-001
```

## 架构对比

### 旧架构 (FS-Bus + Watcher)

```
用户
  ↓
Liaison → 写入 inbox/task-001.json
              ↓
         Watcher (每秒轮询)
              ↓
         读取文件 → 路由 → subprocess 调用 Agent
              ↓
         写入 outbox/task-001.json
              ↓
         Webhook 通知
```

**缺点**：
- Watcher 单点故障
- 文件 I/O 性能差
- 轮询延迟 1 秒
- 需要维护 Python 脚本

### 新架构 (Gateway 原生)

```
用户
  ↓
Liaison → Gateway API (HTTP/WebSocket)
              ↓
         任务队列 (内存 + 持久化)
              ↓
         事件驱动调度
              ↓
         Agent 执行 (异步)
              ↓
         WebSocket 实时推送
```

**优点**：
- 事件驱动，无延迟
- 原生状态追踪
- 水平扩展
- 无需维护 Watcher

## 下一步改造

接下来的改造将关注：

1. **路由方案**：联络官如何将任务分给其他 Agent
2. **Agent 交互**：各 Agent 如何主动交互
3. **进度推送**：任务状态如何通过联络员主动推送给用户

请继续查看后续改造指南。
