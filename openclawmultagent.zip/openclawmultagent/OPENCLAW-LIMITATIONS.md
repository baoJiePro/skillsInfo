# OpenClaw 多 Agent 架构限制与解决方案

## 官方限制说明

根据 OpenClaw 官方文档和源码分析，**OpenClaw 原生不支持以下功能**：

### ❌ 不支持的配置

1. **`openclaw.json` 不支持 `agents` 字段**
   - 无法在一个配置文件中定义多个 Agent
   - 每个 Agent 需要独立的 system prompt 文件

2. **不支持内置路由 (`routing`)**
   - 没有消息路由配置
   - 没有自动 Agent 选择机制

3. **不支持任务队列 (`taskQueue`)**
   - 没有内置的任务队列管理
   - 没有任务状态追踪

4. **不支持多 Agent 协作编排**
   - 没有内置的 Agent 间通信机制
   - 没有任务分配和负载均衡

## 官方支持的功能

### ✅ 支持的配置

```json
{
  "agent": {
    "model": "anthropic/claude-sonnet-4",
    "defaults": {
      "workspace": "~/.openclaw/workspace",
      "sandbox": {
        "mode": "non-main",
        "allowlist": ["bash", "process", "read", "write", "sessions_spawn"]
      }
    }
  },
  "channels": {
    "telegram": { "botToken": "xxx" },
    "discord": { "token": "xxx" }
  },
  "gateway": {
    "bind": "127.0.0.1:18789"
  }
}
```

### ✅ 支持的功能

1. **`sessions_spawn`** - 创建子会话
   ```javascript
   await sessions_spawn({
     label: "子任务",
     agent: "另一个Agent的system prompt",
     task: "任务内容"
   });
   ```

2. **`sessions_list` / `sessions_send`** - 会话管理
   - 列出所有会话
   - 向指定会话发送消息

3. **多 Channel 接入**
   - Telegram
   - Discord
   - WhatsApp
   - 飞书（通过 Webhook）

## 多 Agent 实现方案

### 方案1：在 Agent System Prompt 中实现（推荐）

**原理**：Liaison Agent 通过 `sessions_spawn` 调用其他 Agent

**实现步骤**：

1. **创建多个 Agent 的 system prompt 文件**
   ```
   ~/.openclaw/agents/
   ├── liaison-spark/
   │   └── system.md
   ├── cto-vogels/
   │   └── system.md
   └── fullstack-dhh/
       └── system.md
   ```

2. **在 Liaison 的 system prompt 中实现路由逻辑**
   ```markdown
   ## 路由规则
   
   当用户提到"架构"时，使用 sessions_spawn 调用 cto-vogels：
   ```javascript
   await sessions_spawn({
     label: "架构设计任务",
     agent: "file://~/.openclaw/agents/cto-vogels/system.md",
     task: userRequest,
     mode: "async"
   });
   ```
   ```

3. **启动时使用 Liaison Agent**
   ```bash
   openclaw run liaison-spark
   ```

**优点**：
- 符合 OpenClaw 设计理念
- 无需额外代码
- Agent 可以自主决策

**缺点**：
- 依赖 LLM 理解路由逻辑
- 需要精心设计 system prompt

### 方案2：应用层实现路由

**原理**：在 OpenClaw 之外构建一个路由层

**架构**：
```
用户消息
  ↓
路由服务 (Node.js/Python)
  ↓
调用 OpenClaw CLI/API
  ↓
返回结果给用户
```

**实现步骤**：

1. **创建路由服务**
   ```javascript
   // router.js
   const { exec } = require('child_process');
   
   function routeTask(userMessage) {
     // 关键词匹配
     if (userMessage.includes('架构')) {
       return 'cto-vogels';
     }
     if (userMessage.includes('代码')) {
       return 'fullstack-dhh';
     }
     return 'liaison-spark';
   }
   
   app.post('/chat', async (req, res) => {
     const targetAgent = routeTask(req.body.message);
     
     exec(`openclaw run ${targetAgent} --prompt "${req.body.message}"`, 
       (error, stdout) => {
         res.json({ result: stdout });
       }
     );
   });
   ```

2. **部署路由服务**
   ```bash
   node router.js
   ```

**优点**：
- 完全控制路由逻辑
- 可以扩展任务队列、状态追踪
- 不依赖 LLM 理解

**缺点**：
- 需要额外开发和维护
- 增加了系统复杂度

### 方案3：使用 OpenClaw Gateway + 自定义中间件

**原理**：利用 OpenClaw Gateway 的 HTTP API，在中间件中实现路由

**实现步骤**：

1. **启动 Gateway**
   ```bash
   openclaw gateway start
   ```

2. **创建中间件服务**
   ```javascript
   // middleware.js
   const express = require('express');
   const axios = require('axios');
   
   const app = express();
   
   // 路由决策
   function decideAgent(message) {
     if (message.includes('架构')) return 'cto-vogels';
     if (message.includes('代码')) return 'fullstack-dhh';
     return 'liaison-spark';
   }
   
   app.post('/v1/chat', async (req, res) => {
     const agent = decideAgent(req.body.message);
     
     // 调用 OpenClaw Gateway
     const response = await axios.post(
       'http://localhost:18789/v1/sessions/spawn',
       {
         agent: agent,
         task: req.body.message
       }
     );
     
     res.json(response.data);
   });
   
   app.listen(3000);
   ```

**优点**：
- 利用官方 Gateway 功能
- 可以扩展更多功能
- 相对轻量

**缺点**：
- 需要了解 Gateway API
- 需要额外服务

## 推荐方案

### 简单场景（1-3个Agent）

**使用方案1**：在 system prompt 中实现路由

适合：
- Agent 数量少
- 路由逻辑简单
- 快速原型验证

### 复杂场景（5+个Agent）

**使用方案2或3**：应用层实现路由

适合：
- Agent 数量多
- 需要任务队列
- 需要状态追踪
- 需要负载均衡

## 实际部署建议

### 最小可行方案（MVP）

1. **只使用 2 个 Agent**
   - Liaison（入口）
   - Commander（复杂任务处理）

2. **在 Liaison 中简单路由**
   ```markdown
   如果用户提到"复杂"、"系统"、"完整"，
   调用 Commander，否则自己处理。
   ```

3. **逐步扩展**
   - 先验证核心流程
   - 再添加更多 Agent
   - 最后添加任务队列等高级功能

### 生产环境方案

1. **使用方案3（Gateway + 中间件）**
2. **添加 Redis 作为任务队列**
3. **添加数据库记录任务状态**
4. **添加 WebSocket 推送进度**

## 参考资源

- OpenClaw 官方文档：https://docs.openclaw.ai
- OpenClaw GitHub：https://github.com/openclaw/openclaw
- 配置示例：见 `init-gateway.sh` 生成的配置

## 总结

OpenClaw 是一个**单 Agent 优先**的框架，多 Agent 功能需要通过以下方式实现：

1. **Agent 层**：在 system prompt 中实现（简单场景）
2. **应用层**：构建路由服务（复杂场景）
3. **混合层**：Gateway + 中间件（生产场景）

选择哪种方案取决于你的具体需求和复杂度。
