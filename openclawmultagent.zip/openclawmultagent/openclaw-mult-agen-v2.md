# OpenClaw 多 Agent 系统部署指南

## 架构设计

### 核心设计原则

1. **单一入口**：用户只与联络官(Liaison)沟通
2. **快速响应**：联络官不做耗时任务，3秒内响应
3. **异步处理**：复杂任务后台执行，完成后主动通知
4. **专业分工**：12个Agent各司其职，记忆隔离
5. **状态透明**：任务进度实时追踪，主动推送

### 系统架构

```
┌─────────────────────────────────────────────────────────────────┐
│                           用户 (飞书)                            │
└───────────────────────────────┬─────────────────────────────────┘
                                │ ① 发送消息
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Gateway 层                                │
│  ┌─────────────┐    秒级响应    ┌─────────────────────────────┐ │
│  │   Liaison   │ ────────────→ │        任务管理器            │ │
│  │   (Spark)   │               │  ┌─────────────────────┐    │ │
│  │             │ ←──────────── │  │   任务状态机         │    │ │
│  │  职责：      │   状态更新     │  │  PENDING → ASSIGNED │    │ │
│  │  • 秒级响应  │               │  │  ASSIGNED → RUNNING │    │ │
│  │  • 任务创建  │               │  │  RUNNING → COMPLETED│    │ │
│  │  • 进度查询  │               │  └─────────────────────┘    │ │
│  │  • 结果推送  │               │  ┌─────────────────────┐    │ │
│  └─────────────┘               │  │     进度追踪         │    │ │
│                                │  │  • 实时更新           │    │ │
│                                │  │  • WebSocket推送      │    │ │
│                                │  └─────────────────────┘    │ │
│                                └──────────────┬──────────────┘ │
│                                               │                │
│                      ┌────────────────────────┼────────────────┤
│                      │                        │                │
│                      ▼                        ▼                ▼
│             ┌─────────────┐          ┌─────────────┐   ┌──────────┐
│             │  CEO Agent  │◄────────►│  CTO Agent  │◄──►│ 其他专家  │
│             │  (战略分析)  │ 协作通信  │  (架构设计)  │   │  Agent   │
│             │   (耗时)    │          │   (耗时)    │   │  (耗时)  │
│             └─────────────┘          └─────────────┘   └──────────┘
│                    │                        │
│                    └────────────────────────┘
│                               │
│                               ▼
│                  ┌─────────────────────┐
│                  │   任务完成后回调      │
│                  │   → 更新任务状态      │
│                  │   → 推送给Liaison    │
│                  │   → Liaison推送给用户 │
│                  └─────────────────────┘
└─────────────────────────────────────────────────────────────────┘
```

### 组件职责

#### 1. Liaison (联络官 Spark)

**唯一用户入口**，所有用户消息都发给联络官。

**核心职责**：
- ✅ **秒级响应**：所有操作3秒内完成
- ✅ **任务分发**：识别需求，创建任务，分发给专业Agent
- ✅ **进度同步**：查询任务状态，回复用户
- ✅ **结果推送**：接收完成通知，推送给用户

**禁止行为**：
- ❌ 不写代码
- ❌ 不做深度分析
- ❌ 不生成长文档
- ❌ 不执行耗时操作(>10秒)

**响应时间承诺**：

| 操作类型 | 最大响应时间 | 说明 |
|---------|------------|------|
| 简单问候 | 1秒 | 固定模板 |
| 任务创建 | 3秒 | 意图识别 + Gateway调用 |
| 进度查询 | 2秒 | 数据库查询 |
| 完成通知 | 即时 | WebSocket推送 |

#### 2. Gateway (网关)

**中央路由和调度中心**。

**核心功能**：

```javascript
// 任务队列管理
class TaskQueue {
  async enqueue(task) {
    // 持久化到数据库
    // 返回 taskId
  }
  
  async dequeue(agentId) {
    // 根据Agent能力匹配合适任务
  }
}

// Agent调度
class AgentScheduler {
  async dispatch(task) {
    // 根据任务类型路由到对应Agent
    // 支持负载均衡
  }
  
  async spawnSubAgent(parentTask, agentType) {
    // 创建子任务，支持多Agent协作
  }
}

// 状态追踪
class StateTracker {
  async updateProgress(taskId, progress) {
    // 更新任务进度
    // 触发推送通知
  }
  
  async notifyLiaison(taskId, event) {
    // 通知联络官状态变化
  }
}
```

#### 3. 专业Agent集群

12个专业Agent，每个负责特定领域：

| Agent | 职责 | 典型任务 |
|-------|------|---------|
| ceo-bezos | 战略决策 | 商业分析、市场策略、可行性评估 |
| cto-vogels | 技术架构 | 系统设计、技术选型、性能优化 |
| fullstack-dhh | 代码实现 | 编程开发、代码审查、Bug修复 |
| product-norman | 产品设计 | 需求分析、功能规划、用户故事 |
| qa-bach | 质量保障 | 测试方案、自动化测试、质量评估 |
| ui-duarte | 界面设计 | UI设计、视觉规范、设计系统 |
| interaction-cooper | 交互设计 | 用户流程、交互原型、可用性测试 |
| marketing-godin | 营销推广 | 营销策略、内容规划、增长方案 |
| sales-ross | 销售策略 | 销售流程、客户管理、成交策略 |
| operations-pg | 运营管理 | 流程优化、效率提升、资源配置 |
| commander-grove | 任务协调 | 复杂项目统筹、多Agent协作编排 |
| liaison-spark | 用户接口 | 快速响应、任务分发、进度同步 |

每个Agent特点：
- 独立的system prompt（专业领域知识）
- 独立的上下文（不与其他Agent共享）
- 通过Gateway进行协作通信
- 可以创建子任务（sessions_spawn）

## 任务生命周期

### 状态流转

```
┌─────────┐   创建    ┌─────────┐   分配    ┌─────────┐
│ PENDING │ ───────→ │ASSIGNED │ ───────→ │ RUNNING │
│ (待处理) │          │ (已分配) │          │ (执行中) │
└─────────┘          └─────────┘          └────┬────┘
                                               │
         ┌─────────────────────────────────────┘
         │
    ┌────┴────┐
    │ RUNNING │
    │ 子状态:  │
    │ • analyzing  分析中
    │ • designing  设计中
    │ • coding     编码中
    │ • reviewing  审核中
    └────┬────┘
         │
    完成/失败
         │
    ┌────┴────┐
    │COMPLETED│
    │(已完成) │
    └────┬────┘
         │
         ▼
   ┌──────────┐
   │DELIVERED │
   │(已通知用户)│
   └──────────┘
```

### 任务ID格式

**格式**：`TASK-{日期}-{简述}-{序号}`

**示例**：
- `TASK-20240310-ECOM-ARCH-001` - 电商架构设计
- `TASK-20240310-MKT-STRAT-001` - 市场战略分析
- `TASK-20240310-LOGIN-FEAT-001` - 登录功能开发

**简述生成规则**：
1. 从用户需求中提取2-4个核心关键词
2. 使用大写英文缩写
3. 长度控制在3-8个字符
4. 一眼能看出任务类型

## 典型工作流程

### 场景：用户需要设计电商网站

```
用户: "帮我设计一个电商网站的架构"
  ↓
Liaison: "📋 任务已创建: TASK-20240310-ECOM-ARCH-001

🎯 需求识别: 电商网站架构设计
👥 分配专家: CTO (技术架构)
⏱️ 预计耗时: 3-5分钟

✅ 任务已提交，专家正在处理中...
🔔 完成后我会立即通知您"
  ↓ (3秒内完成响应)
Gateway: 分发任务到CTO Agent
  ↓
CTO Agent: 开始架构设计 (耗时3分钟)
  ↓ (进度更新)
Gateway: 通知Liaison进度
  ↓
Liaison: "📊 进度更新 [TASK-20240310-ECOM-ARCH-001]

CTO (架构设计): ████████░░ 80%

最新进展: 已完成技术选型，正在设计数据库模型"
  ↓ (任务完成)
Gateway: 任务完成，通知Liaison
  ↓
Liaison: "✅ 任务完成！ [TASK-20240310-ECOM-ARCH-001]

CTO 已完成电商网站架构设计：

📋 核心方案:
• 前端: Next.js + Tailwind
• 后端: Node.js + PostgreSQL
• 部署: Docker + AWS

📄 完整文档已生成，点击查看 →"
  ↓
用户: 收到完成通知，查看结果
```

## 部署架构

```
┌─────────────────────────────────────────────────────────────────┐
│                         用户设备                                 │
│                      (飞书客户端)                                │
└─────────────────────────────────┬───────────────────────────────┘
                                  │ HTTPS/WebSocket
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                      OpenClaw Gateway                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │   HTTP API  │  │  WebSocket  │  │      任务调度器          │  │
│  │   层        │  │   推送层     │  │  - 任务队列              │  │
│  └─────────────┘  └─────────────┘  │  - Agent路由             │  │
│                                     │  - 状态管理              │  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Agent运行时                          │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │   │
│  │  │ Liaison  │ │   CEO    │ │   CTO    │ │ 其他专家  │   │   │
│  │  │ (Spark)  │ │ (Bezos)  │ │ (Vogels) │ │  Agent   │   │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘   │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                                  │
                                  │ (可选)
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                     持久化存储层                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │  SQLite/    │  │    Redis    │  │      日志存储            │  │
│  │  PostgreSQL │  │  (缓存/队列) │  │                         │  │
│  │  (任务状态)  │  │             │  │                         │  │
│  └─────────────┘  └─────────────┘  └─────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## 快速开始

### 1. 环境准备

```bash
# 检查Node.js版本 (需要22+)
node --version

# 安装OpenClaw CLI
curl -fsSL https://openclaw.ai/install.sh | bash
```

### 2. 部署Agent

```bash
# 运行初始化脚本
chmod +x init-gateway.sh
./init-gateway.sh
```

### 3. 配置环境变量

```bash
cp .env.example .env
# 编辑.env，填写飞书配置
```

### 4. 启动Gateway

```bash
./start-gateway.sh
```

### 5. 验证部署

```bash
# 查看Agent列表
openclaw agents list

# 测试Liaison响应
openclaw run liaison-spark --prompt "你好"

# 查询任务状态
./query-status.sh TASK-20240310-ECOM-ARCH-001
```

## 配置说明

### ⚠️ 重要说明

**OpenClaw 官方 `openclaw.json` 不支持以下配置**：
- ❌ `agents` - 多 Agent 定义
- ❌ `routing` - 路由规则
- ❌ `taskQueue` - 任务队列
- ❌ `stateTracking` - 状态追踪

**多 Agent 功能实现方式**：
1. **Agent 层**：在 Liaison Agent 的 system prompt 中实现路由逻辑
2. **应用层**：在调用代码中实现路由决策，通过 `sessions_spawn` 分发

### openclaw.json（官方格式）

```json
{
  "agent": {
    "model": "anthropic/claude-sonnet-4",
    "defaults": {
      "workspace": "~/.openclaw/agents/liaison-spark/workspace",
      "sandbox": {
        "mode": "non-main",
        "allowlist": ["bash", "process", "read", "write", "sessions_spawn"]
      }
    }
  },
  "channels": {
    "telegram": {
      "botToken": "your-bot-token",
      "groups": {
        "*": {
          "requireMention": false
        }
      }
    },
    "discord": {
      "token": "your-discord-token",
      "dmPolicy": "pairing"
    }
  },
  "gateway": {
    "bind": "127.0.0.1:18789",
    "auth": {
      "mode": "password"
    }
  }
}
```

### 多 Agent 部署方式

由于 OpenClaw 官方不支持多 Agent 配置，需要通过以下方式实现：

**方式1：通过 `sessions_spawn` 动态创建**

```javascript
// Liaison Agent 中使用 sessions_spawn 创建其他 Agent
await sessions_spawn({
  label: "任务-架构设计",
  agent: "cto-vogels",  // 指定目标 Agent
  task: "设计电商网站架构",
  mode: "async"
});
```

**方式2：通过命令行切换 Agent**

```bash
# 使用不同 Agent 处理不同任务
openclaw run cto-vogels --prompt "设计架构"
openclaw run fullstack-dhh --prompt "实现功能"
```

### 官方支持的配置项

根据 OpenClaw 官方文档，支持的配置：

| 配置项 | 说明 | 示例 |
|-------|------|------|
| `agent.model` | 默认模型 | `"anthropic/claude-sonnet-4"` |
| `agent.defaults.workspace` | 工作空间 | `"~/.openclaw/workspace"` |
| `agent.defaults.sandbox` | 沙盒配置 | `{"mode": "non-main"}` |
| `channels.telegram` | Telegram 配置 | `{"botToken": "xxx"}` |
| `channels.discord` | Discord 配置 | `{"token": "xxx"}` |
| `gateway.bind` | Gateway 绑定地址 | `"127.0.0.1:18789"` |
| `gateway.auth` | 认证配置 | `{"mode": "password"}` |

### 环境变量配置

```bash
# .env 文件
TELEGRAM_BOT_TOKEN=your-telegram-bot-token
DISCORD_TOKEN=your-discord-token
OPENCLAW_API_KEY=your-api-key
```
      "appId": "${FEISHU_APP_ID}",
      "appSecret": "${FEISHU_APP_SECRET}"
    }
  },
  "gateway": {
    "port": 18789,
    "host": "127.0.0.1",
    "enableWebSocket": true,
    "taskQueue": {
      "type": "memory",
      "maxSize": 1000,
      "persistPath": "~/.openclaw/data/tasks.json"
    },
    "stateTracking": {
      "enabled": true,
      "storage": "sqlite",
      "path": "~/.openclaw/data/state.db"
    },
    "notifications": {
      "enabled": true,
      "channels": ["websocket", "webhook"],
      "progressInterval": 10
    }
  },
  "routing": {
    "rules": [
      {
        "pattern": "strategy|business|market|competitor",
        "target": "ceo-bezos",
        "priority": 1
      },
      {
        "pattern": "architecture|system|design|tech-stack|performance",
        "target": "cto-vogels",
        "priority": 1
      },
      {
        "pattern": "code|implement|develop|program|bug|feature",
        "target": "fullstack-dhh",
        "priority": 1
      },
      {
        "pattern": "product|requirement|feature|user-story|prd",
        "target": "product-norman",
        "priority": 1
      },
      {
        "pattern": "complex|project|end-to-end|full-cycle",
        "target": "commander-grove",
        "priority": 2
      }
    ],
    "defaultAgent": "liaison-spark"
  }
}
```

## 进阶主题

### 1. Agent间协作

复杂任务需要多个Agent协作时，由Commander Agent协调：

```javascript
// Commander中实现多Agent协作
async function collaborateOnTask(task) {
  const taskId = generateTaskId();
  
  // 并行启动多个专家Agent
  const experts = await Promise.all([
    sessions_spawn({
      label: 'CEO分析',
      agent: 'ceo-bezos',
      task: `任务ID: ${taskId}\n背景: ${task.description}\n请提供商业可行性分析`,
      mode: 'async'
    }),
    sessions_spawn({
      label: 'CTO架构',
      agent: 'cto-vogels',
      task: `任务ID: ${taskId}\n背景: ${task.description}\n请设计技术架构方案`,
      mode: 'async'
    }),
    sessions_spawn({
      label: 'Product需求',
      agent: 'product-norman',
      task: `任务ID: ${taskId}\n背景: ${task.description}\n请分析用户需求`,
      mode: 'async'
    })
  ]);
  
  // 整合各专家意见
  const finalPlan = synthesizeResults(experts);
  
  // 通知联络官
  await notifyLiaison(taskId, 'analysis_complete', finalPlan);
  
  return finalPlan;
}
```

### 2. 进度推送机制

```javascript
// 任务管理器中的推送逻辑
class TaskManager {
  async updateProgress(taskId, agentId, progress, message) {
    // 1. 更新数据库
    await db.tasks.update(taskId, {
      [`progress.${agentId}`]: progress,
      lastUpdate: new Date()
    });
    
    // 2. 推送给联络官
    await this.notifyLiaison({
      taskId,
      type: 'progress_update',
      agent: agentId,
      progress,
      message,
      timestamp: new Date().toISOString()
    });
  }
  
  async notifyLiaison(notification) {
    // 通过Gateway API发送给联络官
    await fetch('http://localhost:18789/v1/agents/liaison-spark/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(notification)
    });
  }
}
```

### 3. 监控运维

```bash
# 查看Gateway状态
curl http://localhost:18789/health

# 查看任务队列
curl http://localhost:18789/v1/tasks/queue

# 查看Agent状态
curl http://localhost:18789/v1/agents/status
```

## 文件清单

| 文件 | 说明 |
|-----|------|
| `agentsInfo/liaison-spark-v2.md` | 联络官Agent定义 |
| `agentsInfo/commander-grove.md` | 指挥官Agent定义 |
| `agentsInfo/ceo-bezos.md` | CEO Agent定义 |
| `agentsInfo/cto-vogels.md` | CTO Agent定义 |
| `agentsInfo/*.md` | 其他专业Agent定义 |
| `init-gateway.sh` | Gateway初始化脚本 |
| `start-gateway.sh` | Gateway启动脚本 |
| `query-status.sh` | 任务状态查询脚本 |
| `.env.example` | 环境变量模板 |
