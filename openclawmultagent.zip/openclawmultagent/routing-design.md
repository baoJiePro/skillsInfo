# 联络官路由方案设计

## 设计目标

让联络官能够：
1. **快速识别**用户意图（3秒内）
2. **精准匹配**最合适的Agent
3. **支持多Agent协作**处理复杂任务

## 路由决策流程

```
用户消息
    │
    ▼
┌─────────────────────────────────────┐
│ 第1步：判断消息类型                  │
│ • 问候/简单问题 → 直接回复           │
│ • 进度查询 → 查状态后回复            │
│ • 任务需求 → 继续路由                │
└─────────────────┬───────────────────┘
                  │ 是任务需求
                  ▼
┌─────────────────────────────────────┐
│ 第2步：关键词匹配（快速）             │
│ 检查用户消息中的关键词               │
└─────────────────┬───────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│ 第3步：确定目标Agent                 │
│ 根据关键词选择专业Agent              │
└─────────────────┬───────────────────┘
                  │
                  ▼
┌─────────────────────────────────────┐
│ 第4步：评估复杂度                    │
│ • 简单 → 单Agent                     │
│ • 中等 → 串行多Agent                 │
│ • 复杂 → 并行多Agent + Commander     │
└─────────────────┬───────────────────┘
                  │
                  ▼
            创建任务并分发
```

## 关键词匹配表

| 用户提到 | 目标Agent | 复杂度 |
|---------|----------|--------|
| 战略、商业、市场、竞品、商业模式 | ceo-bezos | medium |
| 架构、技术选型、系统设计、性能优化 | cto-vogels | medium |
| 代码、开发、编程、bug、功能实现 | fullstack-dhh | simple |
| 产品、需求、功能、用户故事、PRD | product-norman | medium |
| UI、界面、视觉、设计稿、原型 | ui-duarte | simple |
| 测试、质量、验收、自动化测试 | qa-bach | simple |
| 营销、推广、运营、增长、SEO | marketing-godin | medium |
| 销售、客户、渠道、成交、CRM | sales-ross | medium |
| 运营、流程、效率、管理、SOP | operations-pg | medium |
| 交互、体验、用户研究、可用性 | interaction-cooper | medium |
| 系统、平台、完整、全流程、端到端 | commander-grove | complex |

## 复杂度判断规则

### 简单任务（single）

**特征**：
- 单一领域问题
- 明确具体的技术/设计点
- 预计2-5分钟完成

**示例**：
- "优化这段代码"
- "设计登录页面UI"
- "写单元测试"

**路由**：分发给1个专业Agent

### 中等任务（sequential）

**特征**：
- 需要多个阶段
- 有明确的依赖关系
- 预计5-10分钟完成

**示例**：
- "开发一个社交APP"
- "设计电商网站"

**路由**：串行分发给多个Agent
```
Product（需求）→ CTO（架构）→ FullStack（实现）
```

### 复杂任务（parallel）

**特征**：
- 涉及多个领域
- 需要专家并行分析
- 预计10-15分钟完成

**示例**：
- "开发完整的电商平台"
- "从0到1构建SaaS产品"

**路由**：并行分发给多个Agent，由Commander统筹
```
        ┌→ CEO（商业分析）
        ├→ CTO（架构设计）
Commander ├→ Product（需求分析）
        └→ UI（界面设计）
```

## 实现代码

### 关键词匹配

```javascript
function matchAgent(userMessage) {
  const patterns = {
    'ceo-bezos': /战略|商业|市场|竞品|商业模式/i,
    'cto-vogels': /架构|技术选型|系统设计|性能/i,
    'fullstack-dhh': /代码|开发|编程|bug|功能实现/i,
    'product-norman': /产品|需求|功能|用户故事|PRD/i,
    'ui-duarte': /UI|界面|视觉|设计稿|原型/i,
    'qa-bach': /测试|质量|验收|自动化测试/i,
    'marketing-godin': /营销|推广|运营|增长|SEO/i,
    'sales-ross': /销售|客户|渠道|成交|CRM/i,
    'operations-pg': /运营|流程|效率|管理|SOP/i,
    'interaction-cooper': /交互|体验|用户研究|可用性/i,
    'commander-grove': /系统|平台|完整|全流程|端到端/i
  };
  
  for (const [agent, pattern] of Object.entries(patterns)) {
    if (pattern.test(userMessage)) {
      return agent;
    }
  }
  
  // 默认转给Commander
  return 'commander-grove';
}
```

### 复杂度评估

```javascript
function assessComplexity(userMessage) {
  let score = 0;
  
  // 复杂度指标
  const indicators = {
    high: ['完整', '系统', '平台', '全流程', '端到端', '从0到1'],
    medium: ['APP', '网站', '产品', '模块'],
    low: ['代码', '页面', '功能', '接口', 'bug']
  };
  
  indicators.high.forEach(word => {
    if (userMessage.includes(word)) score += 3;
  });
  
  indicators.medium.forEach(word => {
    if (userMessage.includes(word)) score += 2;
  });
  
  indicators.low.forEach(word => {
    if (userMessage.includes(word)) score += 1;
  });
  
  if (score >= 5) return 'complex';
  if (score >= 3) return 'medium';
  return 'simple';
}
```

### 任务分发

```javascript
async function dispatchTask(userMessage, sessionId) {
  // 1. 确定目标Agent
  const targetAgent = matchAgent(userMessage);
  
  // 2. 评估复杂度
  const complexity = assessComplexity(userMessage);
  
  // 3. 生成任务ID
  const taskId = generateTaskId(userMessage);
  
  // 4. 根据复杂度选择路由方式
  if (complexity === 'simple') {
    // 单Agent
    await sessions_spawn({
      label: `任务-${taskId}`,
      agent: targetAgent,
      task: userMessage,
      mode: 'async'
    });
    
    return {
      taskId,
      mode: 'single',
      agent: targetAgent
    };
    
  } else if (complexity === 'medium') {
    // 串行多Agent
    const stages = [
      { agent: 'product-norman', task: '需求分析' },
      { agent: 'cto-vogels', task: '架构设计' },
      { agent: 'fullstack-dhh', task: '代码实现' }
    ];
    
    await sessions_spawn({
      label: `任务-${taskId}`,
      agent: 'commander-grove',
      task: `串行执行：${JSON.stringify(stages)}`,
      mode: 'async'
    });
    
    return {
      taskId,
      mode: 'sequential',
      stages
    };
    
  } else {
    // 并行多Agent
    await sessions_spawn({
      label: `任务-${taskId}`,
      agent: 'commander-grove',
      task: `并行协调多专家完成：${userMessage}`,
      mode: 'async'
    });
    
    return {
      taskId,
      mode: 'parallel',
      coordinator: 'commander-grove'
    };
  }
}
```

## 上下文感知

### 跟进问题识别

如果是跟进问题，保持同一Agent处理：

```javascript
function isFollowUp(userMessage, sessionHistory) {
  // 跟进问题特征词
  const followUpWords = ['呢', '吗', '怎么样', '如何', '那', '还有', '另外'];
  
  // 检查是否是短句（跟进问题通常较短）
  if (userMessage.length < 20) {
    // 检查是否包含跟进词
    return followUpWords.some(word => userMessage.includes(word));
  }
  
  return false;
}
```

### 使用示例

```javascript
// 场景1：简单代码优化
const result1 = await dispatchTask("帮我优化这段代码", "session-001");
// 结果：{ taskId: "TASK-20240310-CODE-OPT-001", mode: "single", agent: "fullstack-dhh" }

// 场景2：架构设计
const result2 = await dispatchTask("设计电商网站架构", "session-002");
// 结果：{ taskId: "TASK-20240310-ECOM-ARCH-001", mode: "single", agent: "cto-vogels" }

// 场景3：完整系统
const result3 = await dispatchTask("开发完整电商平台", "session-003");
// 结果：{ taskId: "TASK-20240310-ECOM-FULL-001", mode: "parallel", coordinator: "commander-grove" }

// 场景4：跟进问题
const isFollow = isFollowUp("那数据库用什么？", history);
// 结果：true → 保持同一Agent
```

## 配置

**注意**：OpenClaw 官方 `openclaw.json` **没有内置 routing 配置项**。路由逻辑需要在 **Liaison Agent 的 system prompt** 中实现，或者通过 **代码层** 实现。

### 方案1：在 Liaison Agent 中实现路由（推荐）

将路由逻辑写入 `agentsInfo/liaison-spark.md` 的 system prompt 中，让 Liaison 自己判断如何分发任务。

### 方案2：通过代码层实现路由

在调用 `sessions_spawn` 之前，先通过代码进行路由判断：

```javascript
// 在应用层实现路由
function routeTask(userMessage) {
  const targetAgent = matchAgent(userMessage);  // 关键词匹配
  const complexity = assessComplexity(userMessage);  // 复杂度评估
  
  return { targetAgent, complexity };
}

// 然后调用 OpenClaw
await sessions_spawn({
  agent: routingResult.targetAgent,
  task: userMessage,
  mode: 'async'
});
```

### 官方支持的 openclaw.json 配置

根据 OpenClaw 官方文档，支持的配置项：

```json
{
  "agent": {
    "model": "anthropic/claude-sonnet-4",
    "defaults": {
      "workspace": "~/.openclaw/workspace",
      "sandbox": {
        "mode": "non-main",
        "allowlist": ["bash", "process", "read", "write", "sessions_spawn"]
      }
    }
  },
  "channels": {
    "telegram": {
      "botToken": "your-token"
    },
    "discord": {
      "token": "your-token"
    }
  },
  "gateway": {
    "bind": "127.0.0.1:18789"
  }
}
```

**重要**：OpenClaw 官方配置**不支持** `routing`、`agents` 等自定义字段。多 Agent 路由需要在应用层或 Agent 层实现。

## 总结

这个路由方案的核心：

1. **关键词匹配** → 快速确定目标Agent
2. **复杂度评估** → 选择单Agent/串行/并行模式
3. **上下文感知** → 跟进问题保持连续性
4. **统一分发** → 通过 `sessions_spawn` 调用Gateway
